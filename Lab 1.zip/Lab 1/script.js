

function showConfirmClick(event) {
  event.preventDefault();
  navigator.notification.alert("Text", () => {}, ['Glorious Alert Box'], ['Exit', 'Restart']);
}
